import { Component } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormControl } from '@angular/forms';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrl: './parent.component.scss'
})
export class ParentComponent {
 formGroup!: FormGroup;

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.formGroup = this.formBuilder.group({
      items: this.formBuilder.array([])
    });
  }

  get items() {
    return this.formGroup.get('items') as FormArray;
  }

  addItem(value: string) {
    this.items.push(this.formBuilder.group({ name: new FormControl(value) }));
  }
}
